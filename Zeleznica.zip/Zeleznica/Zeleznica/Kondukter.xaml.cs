﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for Kondukter.xaml
    /// </summary>
    public partial class Kondukter : Window
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
        int idKorisnika;
        public Kondukter(int IDKorisnika)
        {
            this.idKorisnika = IDKorisnika;
            InitializeComponent();
            LoadDataGrid();
        }
        private void LoadDataGrid()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT Kondukter.* FROM Kondukter";
            cmd.Connection = sqlCon;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable("Kondukter");
            dataAdapter.Fill(dataTable);
            KondukteriGrid.ItemsSource = new DataView(dataTable);
            sqlCon.Close();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtIDK.Text = dr["IDKonduktera"].ToString();
                txtIDVoza.Text = dr["BrojVoza"].ToString();
                txtImePrezimeK.Text = dr["ImePrezime"].ToString();

            }

        }

        private void DodajKonduktera_Click(object sender, RoutedEventArgs e)
        {
            sqlCon.Open();
            string query = "INSERT INTO Kondukter (ImePrezime,BrojVoza) VALUES(@ImePrezime,@BrojVoza)";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@ImePrezime", txtImePrezimeK.Text);
            sqlCmd.Parameters.AddWithValue("@BrojVoza", txtIDVoza.Text);
            try { int provera = sqlCmd.ExecuteNonQuery();
                if (provera == 1)
                {
                    MessageBox.Show("Podaci su uspešno upisani");
                    LoadDataGrid();
                } }
            catch (SqlException error)
            {
                MessageBox.Show("Voz ne postoji! Proverite koji vozovi postoje, ili unesite nov u tabeli VOZ ");
            }
            PonistiUnosTxt();
            }
        private void PonistiUnosTxt()
        {
            txtImePrezimeK.Text = "";
            txtIDVoza.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            string query = "DELETE FROM Kondukter WHERE ImePrezime=@Ime";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@Ime", txtImePrezimeK.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno obrisani");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            string query = "UPDATE Kondukter SET ImePrezime = @Ime, BrojVoza = @IDV WHERE IDKonduktera = @IDK";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            
            sqlCmd.Parameters.AddWithValue("@IDK", txtIDK.Text);
            sqlCmd.Parameters.AddWithValue("@Ime", txtImePrezimeK.Text);
            sqlCmd.Parameters.AddWithValue("@IDV", txtIDVoza.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno promenjeni");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }

        private void btnNazad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objMW = new MainWindow(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }
    }
}
