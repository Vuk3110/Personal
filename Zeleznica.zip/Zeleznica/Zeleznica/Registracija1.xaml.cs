﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for Registracija.xaml
    /// </summary>
    public partial class Registracija : Window
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
        public Registracija()
        {
            InitializeComponent();
        }

        private void btnSledece_Click(object sender, RoutedEventArgs e)
        {
            sqlCon.Open();
            string query = "INSERT INTO Korisnik (KorisnickoIme,Lozinka) VALUES(@KorisnickoIme,@Lozinka)";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@KorisnickoIme", txtKorisnickoIme.Text);
            sqlCmd.Parameters.AddWithValue("@Lozinka", txtLozinka.Text);
            int provera = sqlCmd.ExecuteNonQuery();
        

            string query2 = "select Korisnik.IDKorisnika from Korisnik where @KorisnickoIme=Korisnik.KorisnickoIme";
            SqlCommand sqlCmd2 = new SqlCommand(query2, sqlCon);
            sqlCmd2.CommandType = CommandType.Text;
            sqlCmd2.Parameters.AddWithValue("@KorisnickoIme", txtKorisnickoIme.Text);
            int idk=(int)sqlCmd2.ExecuteScalar();  

            string query3 = "insert into Putnik (ImePrezime,IDKorisnika) values(@imeprezime,@idkorisnika)";
            SqlCommand sqlCmd3 = new SqlCommand(query3, sqlCon);
            sqlCmd3.CommandType = CommandType.Text;
            sqlCmd3.Parameters.AddWithValue("@imeprezime", txtImePrezime.Text);
            sqlCmd3.Parameters.AddWithValue("@idkorisnika", idk);
            int proveraP = sqlCmd3.ExecuteNonQuery();
            if (proveraP == 1)
            {
                MessageBox.Show("Putnik uspešno upisan");
                Login objMW = new Login();
                Visibility = Visibility.Hidden;
                objMW.Show();
            }
            PonistiUnosTxt();
           
           
        }
        private void PonistiUnosTxt()
        {
            txtKorisnickoIme.Text = "";
            txtLozinka.Text = "";
           
        }

        private void btnNazad_Click(object sender, RoutedEventArgs e)
        {
            Login objMW = new Login();
            Visibility = Visibility.Hidden;
            objMW.Show();
        }
    }
}
