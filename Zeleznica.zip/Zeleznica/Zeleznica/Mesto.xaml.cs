﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for Mesto.xaml
    /// </summary>
    public partial class Mesto : Window
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
        int idKorisnika;
        public Mesto(int IDKorisnika)
        {   this.idKorisnika = IDKorisnika;
            InitializeComponent();
            LoadDataGrid();
        }
        private void LoadDataGrid()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT Mesto.* FROM Mesto";
                
                
            cmd.Connection = sqlCon;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable("Mesto");
            dataAdapter.Fill(dataTable);
            MestoGrid.ItemsSource = new DataView(dataTable);
            sqlCon.Close();
        }
      
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            sqlCon.Open();
            string query = "INSERT INTO Mesto (PTT,Naziv) VALUES(@PTT,@Naziv)";
           
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@PTT", txtPTT.Text);
            sqlCmd.Parameters.AddWithValue("@Naziv", txtNaziv.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno upisani");
                LoadDataGrid();
            }
           
        }
        

        private void btnNazad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objMW = new MainWindow(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtPTT.Text = dr["PTT"].ToString();
                
                txtNaziv.Text = dr["Naziv"].ToString();

            }

        }
       
        private void PonistiUnosTxt()
        {
            txtPTT.Text = "";
            txtNaziv.Text = "";
        }
    }
}

