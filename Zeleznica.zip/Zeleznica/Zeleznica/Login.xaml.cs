﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    { int IDKorisnika = -1;
        public Login()
        {
            InitializeComponent();
        }

        private void btnPrijava_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                String query = "select Korisnik.IDKorisnika " +
                    "from Korisnik " +
                 
                    "where Korisnik.korisnickoIme =@korisnickoIme " +
                    "and lozinka =@lozinka";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@korisnickoIme ", txtKorisnickoIme.Text);
                sqlCmd.Parameters.AddWithValue("@lozinka", txtLozinka.Password);
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                    IDKorisnika = reader.GetInt32(0);
                if (IDKorisnika != -1)
                {
                    MainWindow objMW = new MainWindow(IDKorisnika);
                    Visibility = Visibility.Hidden;
                    objMW.Show();
                }
                else
                {
                    MessageBox.Show("Username or password is incorect!");
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }


        }

        private void btnRegistracija_Click(object sender, RoutedEventArgs e)
        {
            Registracija objMW = new Registracija();
            Visibility = Visibility.Hidden;
            objMW.Show();
        }
    } }

