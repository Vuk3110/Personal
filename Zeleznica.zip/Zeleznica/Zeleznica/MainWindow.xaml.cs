﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
        int idKorisnika;
        List<string> vremePolaska = new List<string>();
        public MainWindow(int IDKorisnika)

        {
            InitializeComponent();
            DodajCmbVreme();
           
            LoadDataGrid();
            this.idKorisnika = IDKorisnika;
           
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {

            string datum = formatiranjeDatuma();
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            string queryZaVoz = "select top 1 IDVoza " +
                                    "from Voz " +
                                    "order by NEWID() ";
            SqlCommand sqlCmd2 = new SqlCommand(queryZaVoz, sqlCon);
            SqlDataReader reader = sqlCmd2.ExecuteReader();
            int IDVoza = -1;
            if (reader.Read())
                IDVoza = reader.GetInt32(0);
            reader.Close();
            Random random = new Random();
            float cena = random.Next(300, 700);
            cena = (float)System.Math.Round(cena, 2);
            string query = "INSERT INTO Karta (CenaKarte,IDVoza,IDPutnika,MestoPolaska,MestoDolaska,DatumPolaska) VALUES(@cena, @idVoza, @idPutnika,@mestoPolaska,@mestoDolaska,@DatumPolaska)";
            string query3 = "select IDPutnika from Putnik,Korisnik where Putnik.IDKorisnika=@IDKorisnika ";


            SqlCommand sqlCmd3 = new SqlCommand(query3, sqlCon);
            sqlCmd3.CommandType = CommandType.Text;
            sqlCmd3.Parameters.AddWithValue("@IDKorisnika", idKorisnika);
            int IDk = (int)sqlCmd3.ExecuteScalar();




            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@cena", cena);
            sqlCmd.Parameters.AddWithValue("@idPutnika", IDk);
            sqlCmd.Parameters.AddWithValue("@mestoPolaska", vratiIdMesta("polazak"));
            sqlCmd.Parameters.AddWithValue("@mestoDolaska", vratiIdMesta("dolazak"));
            sqlCmd.Parameters.AddWithValue("@DatumPolaska", datum);
            sqlCmd.Parameters.AddWithValue("@idVoza", IDVoza);
            
            try
            {int provera = sqlCmd.ExecuteNonQuery();
                if (provera == 1)
                {
                    MessageBox.Show("Podaci su uspešno upisani");
                    LoadDataGrid();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show("Mesto ne postoji! Unesite mesto u opciiji MESTA ");

            }
        }
        private void LoadDataGrid()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT BrojKarte, CenaKarte, Karta.IDVoza, Putnik.ImePrezime, mp.Naziv as [MestoPolaska] ,md.Naziv as [MestoDolaska], DatumPolaska FROM Karta " +
                              "join Putnik on Karta.IDPutnika = Putnik.IDPutnika "+
                              "join Voz on Karta.IDVoza = Voz.IDVoza "+
                              "join Mesto md on Karta.MestoDolaska = md.PTT "+
                              "join Mesto mp on Karta.MestoPolaska = mp.PTT ";
            cmd.Connection = sqlCon;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable("Karta");
            dataAdapter.Fill(dataTable);
            KarteGrid.ItemsSource = new DataView(dataTable);
            sqlCon.Close();
        }

        private long vratiIdMesta(string odabir)
        {
            string query = "select Mesto.PTT from Mesto where Mesto.Naziv =@mesto ";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            if (odabir == "polazak")
                sqlCmd.Parameters.AddWithValue("@mesto", txtMestoPolaska.Text);
            else
                sqlCmd.Parameters.AddWithValue("@mesto", txtMestoDolaska.Text);
            SqlDataReader reader = sqlCmd.ExecuteReader();
            long idMesta = -1;
            if (reader.Read())
                idMesta = reader.GetInt64(0);
            reader.Close();

            return idMesta;
        }

        private void DodajCmbVreme()
        {
            for (int i = 8; i < 21; i++)
                for (int k = 0, j = 0; j < 2; j++, k += 30)
                {
                    if (k == 0)
                        vremePolaska.Add(i.ToString() + ":" + k.ToString() + "0" + ":" + "00");
                    else
                        vremePolaska.Add(i.ToString() + ":" + k.ToString() + ":" + "00");

                }
            cmbVreme.ItemsSource = vremePolaska;
        }

        private string formatiranjeDatuma()
        {
            string[] datumPolaska = dtpDatum.Text.Split("/");
            string vremePolaska = (string)cmbVreme.SelectedItem;
            string dan = datumPolaska[0];
            string mesec = datumPolaska[1];
            string godina = datumPolaska[2];
            string terminPolaska = godina + "-" + mesec + "-" + dan + " " + vremePolaska ;

            return terminPolaska;
        }


        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtMestoPolaska.Text = dr["MestoPolaska"].ToString();
                txtMestoDolaska.Text = dr["MestoDolaska"].ToString();
                string[] vreme = dr["DatumPolaska"].ToString().Split(" ");
                cmbVreme.SelectedItem = vreme[1];
                dtpDatum.Text = vreme[0];
                txtBrojKarte.Text = dr["BrojKarte"].ToString();


            }

        }

        private void btnObrisi_Click(object sender, RoutedEventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            string query = "DELETE FROM Karta WHERE BrojKarte=@brojKarte";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@brojKarte", txtBrojKarte.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno obrisani");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }

        private void btnIzmeni_Click(object sender, RoutedEventArgs e)
        {
            string datum = formatiranjeDatuma();
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            
            string query = "UPDATE Karta SET MestoPolaska = @mestoPolaska, MestoDolaska = @mestoDolaska,DatumPolaska=@vremePolaska WHERE BrojKarte = @brojKarte";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@mestoPolaska", vratiIdMesta("polazak"));
            sqlCmd.Parameters.AddWithValue("mestoDolaska", vratiIdMesta("dolazak"));
            sqlCmd.Parameters.AddWithValue("@vremePolaska", datum);
            sqlCmd.Parameters.AddWithValue("@brojKarte", txtBrojKarte.Text);

            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno promenjeni");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }


        private void PonistiUnosTxt()
        {
            txtMestoDolaska.Text = "";
            txtMestoPolaska.Text = "";
            cmbVreme.SelectedIndex = 0;
            dtpDatum.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Mesto objMW = new Mesto(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Kondukter objMW = new Kondukter(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Voz objMW = new Voz(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Login objMW = new Login();
            Visibility = Visibility.Hidden;
            objMW.Show();
        }
    }
    }



