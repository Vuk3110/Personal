﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace Zeleznica
{
    /// <summary>
    /// Interaction logic for Voz.xaml
    /// </summary>
    public partial class Voz : Window
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-U7EEFNU\SQLEXPRESS;Initial Catalog=ZELEZNICA;Integrated Security=True");
        int idKorisnika;
        public Voz(int IDKorisnika)
        {
            this.idKorisnika = IDKorisnika;
            InitializeComponent();
            LoadDataGrid();
        }


        private void LoadDataGrid()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT Voz.* FROM Voz";
            cmd.Connection = sqlCon;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable("Voz");
            dataAdapter.Fill(dataTable);
            VozoviGrid.ItemsSource = new DataView(dataTable);
            sqlCon.Close();
        }
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtIDVoza.Text = dr["IDVoza"].ToString();
                txtModel.Text = dr["Model"].ToString();
                txtBrojSedista.Text = dr["BrojSedista"].ToString();

            }

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            sqlCon.Open();
            string query = "INSERT INTO Voz (Model,BrojSedista) VALUES(@model,@brojSedista)";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@model", txtModel.Text);
            sqlCmd.Parameters.AddWithValue("@brojSedista", txtBrojSedista.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno upisani");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }

        private void PonistiUnosTxt()
        {
            txtModel.Text = "";
            txtBrojSedista.Text = "";
        }

        private void btnNazad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objMW = new MainWindow(idKorisnika);
            Visibility = Visibility.Hidden;
            objMW.Show();
        }

        private void btnObrisiVoz_Click(object sender, RoutedEventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            string query = "DELETE FROM Voz WHERE IDVoza=@IDV";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@IDV", txtIDVoza.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno obrisani");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }

        private void btnIzmeniVoz_Click(object sender, RoutedEventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            string query = "UPDATE Voz SET Model= @Model, BrojSedista = @BrojS WHERE IDVoza = @IDV";
            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
            sqlCmd.CommandType = CommandType.Text;

            sqlCmd.Parameters.AddWithValue("@IDV", txtIDVoza.Text);
            sqlCmd.Parameters.AddWithValue("@Model", txtModel.Text);
            sqlCmd.Parameters.AddWithValue("@BrojS", txtBrojSedista.Text);
            int provera = sqlCmd.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno promenjeni");
                LoadDataGrid();
            }
            PonistiUnosTxt();
        }
    }
}
